from django.apps import AppConfig


class SendMessagesConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'send_messages'

from django.shortcuts import render
from rest_framework import generics
from tables import models
from tables import serializers
from django_filters.rest_framework.backends import DjangoFilterBackend
from rest_framework.permissions import IsAuthenticated  

class TableList(generics.ListCreateAPIView):
    permission_classes = (IsAuthenticated,)
    queryset = models.Table.objects.all()
    serializer_class = serializers.TableSerializer
    filter_backends = [DjangoFilterBackend]
    filter_fields = ['is_active']
    
class TableDetail(generics.RetrieveUpdateDestroyAPIView):
    queryset = models.Table.objects.all()
    serializer_class = serializers.TableSerializer